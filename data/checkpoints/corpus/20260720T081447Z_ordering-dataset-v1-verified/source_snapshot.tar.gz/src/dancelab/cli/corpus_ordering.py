"""Read-only commands for the frozen DJ-mix ordering experiment."""

from __future__ import annotations

from pathlib import Path

import typer


app = typer.Typer(
    name="corpus-ordering",
    help="Build and evaluate ordering-given-observed-crate evidence.",
    no_args_is_help=True,
)


def _build_config(
    *,
    min_match_rate: float,
    allow_unreliable_beatgrid: bool,
):
    from dancelab.validation.djmix.ordering import OrderingBuildConfig

    return OrderingBuildConfig(
        min_match_rate=min_match_rate,
        require_reliable_beatgrid=not allow_unreliable_beatgrid,
    )


@app.command("prepare-features")
def prepare_features(
    analysis_root: Path = typer.Argument(
        ...,
        help="Root containing indexed DanceLab AnalysisResult JSON files",
    ),
    analysis_index: Path = typer.Option(
        ...,
        "--analysis-index",
        help="Explicit catalogue-track ID to relative analysis-path mapping",
    ),
    embeddings: Path = typer.Option(
        ...,
        "--embeddings",
        help="Precomputed embeddings from one pinned, frozen learned-audio model",
    ),
    dj_mapping: Path = typer.Option(
        ...,
        "--dj-map",
        help="Trusted mix ID to DJ ID mapping with provenance",
    ),
    output: Path = typer.Option(
        Path("data/reports/corpus_ordering/features.json"),
        "--output",
        "-o",
        help="Combined H/E feature catalogue destination",
    ),
) -> None:
    """Build a source-backed H/E catalogue without downloading a model."""

    from dancelab.validation.djmix.ordering_features import (
        build_ordering_feature_catalog,
        write_ordering_feature_catalog,
    )

    try:
        catalog = build_ordering_feature_catalog(
            analysis_root=analysis_root,
            analysis_index_path=analysis_index,
            embedding_catalog_path=embeddings,
            dj_mapping_path=dj_mapping,
        )
        destination = write_ordering_feature_catalog(catalog, output)
    except (FileNotFoundError, ValueError) as exc:
        typer.secho(f"BLOCKED: {exc}", fg="red", err=True)
        raise typer.Exit(code=2) from exc

    typer.secho("Source-backed ordering feature catalogue built", fg="green")
    typer.echo(f"tracks: {len(catalog.tracks)}")
    typer.echo(f"H dimensions: {catalog.handcrafted_dimension}")
    typer.echo(f"E dimensions: {catalog.embedding_dimension}")
    typer.echo(f"fingerprint: {catalog.fingerprint}")
    typer.echo(f"wrote: {destination}")


@app.command("build")
def build(
    corpus_root: Path = typer.Argument(..., help="Frozen DanceLabCorpus root"),
    output: Path = typer.Option(
        Path("data/reports/corpus_ordering/dataset.json"),
        "--output",
        "-o",
        help="Immutable dataset snapshot destination",
    ),
    feature_catalog: Path | None = typer.Option(
        None,
        "--features",
        help="Optional feature catalogue; only its trusted DJ mapping is joined",
    ),
    min_match_rate: float = typer.Option(0.4, "--min-match-rate"),
    allow_unreliable_beatgrid: bool = typer.Option(
        False,
        "--allow-unreliable-beatgrid",
        help="Research override; strict reliable-beatgrid gate is the default",
    ),
) -> None:
    """Build Corpus Ordering Dataset v1 without mutating the source corpus."""

    from dancelab.validation.djmix.ordering import (
        build_corpus_ordering_dataset,
        write_ordering_dataset_snapshot,
    )
    from dancelab.validation.djmix.ordering_models import (
        load_ordering_feature_catalog,
    )

    try:
        catalog = (
            load_ordering_feature_catalog(feature_catalog) if feature_catalog is not None else None
        )
        dataset = build_corpus_ordering_dataset(
            corpus_root,
            config=_build_config(
                min_match_rate=min_match_rate,
                allow_unreliable_beatgrid=allow_unreliable_beatgrid,
            ),
            dj_by_mix=catalog.dj_by_mix if catalog is not None else None,
        )
        destination = write_ordering_dataset_snapshot(dataset, output)
    except (FileNotFoundError, ValueError) as exc:
        typer.secho(f"BLOCKED: {exc}", fg="red", err=True)
        raise typer.Exit(code=2) from exc

    typer.secho("Corpus Ordering Dataset v1 built", fg="green")
    typer.echo(f"observations: {len(dataset.observations)}")
    typer.echo(f"mixes: {len(dataset.mix_ids)}")
    typer.echo(f"fingerprint: {dataset.fingerprint}")
    typer.echo(f"wrote: {destination}")


@app.command("check")
def check(
    corpus_root: Path = typer.Argument(..., help="Frozen DanceLabCorpus root"),
    feature_catalog: Path = typer.Option(
        ...,
        "--features",
        help="Source-backed H/E vectors and trusted DJ IDs",
    ),
    min_match_rate: float = typer.Option(0.4, "--min-match-rate"),
) -> None:
    """Report whether the corpus can support the declared five-model test."""

    from dancelab.validation.djmix.ordering import (
        OrderingBuildConfig,
        build_corpus_ordering_dataset,
    )
    from dancelab.validation.djmix.ordering_models import (
        assess_ordering_model_readiness,
        load_ordering_feature_catalog,
    )

    try:
        catalog = load_ordering_feature_catalog(feature_catalog)
        dataset = build_corpus_ordering_dataset(
            corpus_root,
            config=OrderingBuildConfig(min_match_rate=min_match_rate),
            dj_by_mix=catalog.dj_by_mix,
        )
        readiness = assess_ordering_model_readiness(dataset, catalog)
    except (FileNotFoundError, ValueError) as exc:
        typer.secho(f"BLOCKED: {exc}", fg="red", err=True)
        raise typer.Exit(code=2) from exc

    color = "green" if readiness.ready_for_five_models else "yellow"
    status = "READY" if readiness.ready_for_five_models else "BLOCKED"
    typer.secho(f"{status}: five-model ordering evaluation", fg=color)
    typer.echo(f"observations: {readiness.eligible_observations}/{readiness.total_observations}")
    typer.echo(f"eligible mixes: {readiness.eligible_mix_count}")
    typer.echo(f"trusted DJs: {readiness.eligible_dj_count}")
    for blocker in readiness.blockers:
        typer.secho(f"- {blocker}", fg="yellow")
    if not readiness.ready_for_five_models:
        raise typer.Exit(code=2)


@app.command("evaluate")
def evaluate(
    corpus_root: Path = typer.Argument(..., help="Frozen DanceLabCorpus root"),
    feature_catalog: Path = typer.Option(
        ...,
        "--features",
        help="Source-backed H/E vectors and trusted DJ IDs",
    ),
    output: Path = typer.Option(
        Path("data/reports/corpus_ordering/five_model_report.json"),
        "--output",
        "-o",
    ),
    min_match_rate: float = typer.Option(0.4, "--min-match-rate"),
    l2: float = typer.Option(0.1, "--l2"),
    dj_l2: float = typer.Option(1.0, "--dj-l2"),
    max_iterations: int = typer.Option(400, "--max-iterations"),
    include_model_parameters: bool = typer.Option(
        False,
        "--include-model-parameters",
    ),
) -> None:
    """Run L0/LH/LE/LHE/LHEI on one immutable held-out universe."""

    from dancelab.validation.djmix.ordering import (
        OrderingBuildConfig,
        build_corpus_ordering_dataset,
    )
    from dancelab.validation.djmix.ordering_models import (
        OrderingTrainingConfig,
        load_ordering_feature_catalog,
        train_five_model_ordering_evaluation,
        write_five_model_ordering_report,
    )

    try:
        catalog = load_ordering_feature_catalog(feature_catalog)
        dataset = build_corpus_ordering_dataset(
            corpus_root,
            config=OrderingBuildConfig(min_match_rate=min_match_rate),
            dj_by_mix=catalog.dj_by_mix,
        )
        report = train_five_model_ordering_evaluation(
            dataset,
            catalog,
            config=OrderingTrainingConfig(
                l2=l2,
                dj_l2=dj_l2,
                max_iterations=max_iterations,
            ),
        )
        destination = write_five_model_ordering_report(
            report,
            output,
            include_model_parameters=include_model_parameters,
        )
    except (FileNotFoundError, ValueError) as exc:
        typer.secho(f"BLOCKED: {exc}", fg="red", err=True)
        raise typer.Exit(code=2) from exc

    typer.secho("Five-model held-out evaluation complete", fg="green")
    for name, metrics in report.test_metrics.items():
        typer.echo(f"{name}: total NLL {metrics.total_nll:.4f} | top-1 {metrics.top1_accuracy:.1%}")
    typer.echo(
        "decomposition: "
        f"C_rule={report.decomposition.c_rule:.3f}, "
        f"C_sim={report.decomposition.c_similarity:.3f}, "
        f"I={report.decomposition.identity:.3f}, "
        f"N={report.decomposition.residual:.3f}"
    )
    for warning in report.warnings:
        typer.secho(f"warn: {warning}", fg="yellow")
    typer.echo(f"evaluation hash: {report.evaluation_hash}")
    typer.echo(f"wrote: {destination}")
