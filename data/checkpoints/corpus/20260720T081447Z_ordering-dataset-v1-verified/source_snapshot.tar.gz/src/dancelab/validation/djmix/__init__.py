"""Offline DJ-mix validation based on mix-to-track subsequence alignment.

This package is a measurement add-on. It consumes local audio and emits
validation results; it does not alter engine analyses, rankings, BPM values, or
Rekordbox exports.
"""

from dancelab.validation.djmix.alignment import align_feature_sequences, diagonal_match_rate
from dancelab.validation.djmix.confidence import (
    assess_boundary_confidence,
    score_cue_candidates,
)
from dancelab.validation.djmix.cues import extract_cue_candidates
from dancelab.validation.djmix.decomposition import (
    CrateOverlapReport,
    DecompositionResult,
    MeasuredLoss,
    ModelLosses,
    assess_crate_overlap,
    block_bootstrap_set_ids,
    combine_joint_losses,
    decompose_losses,
    evaluation_fingerprint,
    fixed_size_selection_nll,
    log_fixed_size_partition,
    random_selection_baseline_nll,
)
from dancelab.validation.djmix.evaluation import evaluate_boundary_predictions
from dancelab.validation.djmix.features import (
    combine_feature_blocks,
    extract_beat_synchronous_features,
)
from dancelab.validation.djmix.identity import identify_audio_file
from dancelab.validation.djmix.models import (
    AlignmentResult,
    AudioIdentity,
    BeatFeatureSequence,
    BoundaryConfidence,
    CueCandidate,
    TransitionEvidence,
)
from dancelab.validation.djmix.ordering import (
    CorpusOrderingDataset,
    OrderingBuildConfig,
    OrderingObservation,
    build_corpus_ordering_dataset,
    write_ordering_dataset_snapshot,
)
from dancelab.validation.djmix.ordering_features import (
    HANDCRAFTED_FEATURE_NAMES,
    FrozenEmbeddingCatalog,
    build_ordering_feature_catalog,
    handcrafted_features_from_analysis,
    load_frozen_embedding_catalog,
    load_trusted_dj_mapping,
    write_ordering_feature_catalog,
)
from dancelab.validation.djmix.ordering_models import (
    FiveModelOrderingReport,
    OrderingFeatureCatalog,
    OrderingReadinessReport,
    OrderingTrainingConfig,
    assess_ordering_model_readiness,
    load_ordering_feature_catalog,
    train_five_model_ordering_evaluation,
    write_five_model_ordering_report,
)
from dancelab.validation.djmix.transitions import assemble_transition_evidence

__all__ = [
    "AlignmentResult",
    "AudioIdentity",
    "BeatFeatureSequence",
    "BoundaryConfidence",
    "CrateOverlapReport",
    "CueCandidate",
    "DecompositionResult",
    "FiveModelOrderingReport",
    "FrozenEmbeddingCatalog",
    "HANDCRAFTED_FEATURE_NAMES",
    "MeasuredLoss",
    "ModelLosses",
    "CorpusOrderingDataset",
    "OrderingBuildConfig",
    "OrderingFeatureCatalog",
    "OrderingObservation",
    "OrderingReadinessReport",
    "OrderingTrainingConfig",
    "TransitionEvidence",
    "align_feature_sequences",
    "assemble_transition_evidence",
    "assess_crate_overlap",
    "assess_boundary_confidence",
    "block_bootstrap_set_ids",
    "build_corpus_ordering_dataset",
    "build_ordering_feature_catalog",
    "combine_feature_blocks",
    "combine_joint_losses",
    "decompose_losses",
    "diagonal_match_rate",
    "evaluation_fingerprint",
    "evaluate_boundary_predictions",
    "extract_beat_synchronous_features",
    "extract_cue_candidates",
    "fixed_size_selection_nll",
    "handcrafted_features_from_analysis",
    "identify_audio_file",
    "load_ordering_feature_catalog",
    "load_frozen_embedding_catalog",
    "load_trusted_dj_mapping",
    "log_fixed_size_partition",
    "random_selection_baseline_nll",
    "score_cue_candidates",
    "assess_ordering_model_readiness",
    "train_five_model_ordering_evaluation",
    "write_five_model_ordering_report",
    "write_ordering_feature_catalog",
    "write_ordering_dataset_snapshot",
]
